package com.gummyslug.opc;


import org.junit.Test;

public class ColorTest {

	@Test
	public void testGetHSV() {
		
	byte b = (byte) 200;
	int t = b;
	System.out.println(t);
		
//		Color hsv = Color.getHSV(1000, 256, 256);
//		Assert.assertEquals(hsv.red, 255);
	}

}
