package com.gummyslug.processing;

import com.gummyslug.processing.opc.OPC;

import processing.core.PApplet;

public class GridPixels extends PApplet {

	private OPC opc;

	int red = color(255f, 0f, 0f);

	public void setup() {
		size(OPC.WIDTH, OPC.HEIGHT);
		opc = new OPC(this);
		opc.setDefault2();
	}

	public void drawBox(int x, int y, int color) {
		int boxWidth = OPC.WIDTH / 32;
		int boxHeight = OPC.HEIGHT / 16;

		x = x % 32;
		y = y % 16;
		fill(color);
		// rect(x * boxWidth + 2, y * boxHeight + 2, boxWidth, boxHeight);
		ellipse(x * boxWidth + boxWidth / 2 + 3, y * boxHeight + boxHeight / 2 + 3, boxWidth / 2, boxHeight / 2);
	}

	public void draw() {
		background(0);
		drawBox(10, 10, red);
	}
}
