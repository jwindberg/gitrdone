package com.gummyslug.processing.opc;

import processing.core.PApplet;
import processing.core.PConstants;

public abstract class AnimationApplet extends PApplet {

	protected OPC opc;

	private static final long serialVersionUID = 1L;

	@Override
	public void setup() {
		super.setup();
		opc = new OPC(this);
		opc.setSize4(getRenderer());
		opc.setDefault4();
		setupInternal();
	}

	protected String getRenderer() {
		return PConstants.JAVA2D;
	}

	protected void setupInternal() {
		// do what you will here.
	}

	@Override
	public void dispose() {
		super.dispose();
		opc.clear();
	}

}
