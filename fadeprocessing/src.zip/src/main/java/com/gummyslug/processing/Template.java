package com.gummyslug.processing;

import com.gummyslug.processing.opc.OPC;

import processing.core.PApplet;

public class Template extends PApplet {

	private static final long serialVersionUID = 1L;

	private OPC opc;

	public void setup() {
		size(OPC.WIDTH, OPC.HEIGHT);
		opc = new OPC(this);
		opc.setDefault2();
	}

	public void draw() {

	}

}
